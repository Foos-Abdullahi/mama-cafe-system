<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" @class(['dark' => ($appearance ?? 'system') == 'dark'])>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        {{-- Inline script to detect system dark mode preference and apply it immediately --}}
        <script>
            (function() {
                const appearance = '{{ $appearance ?? "system" }}';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
            })();
        </script>

        {{-- Inline style to set the HTML background color based on our theme in app.css --}}
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <link rel="icon" href="{{ asset('mama-cafe-logo.png') }}" type="image/png">
        <link rel="apple-touch-icon" href="{{ asset('mama-cafe-logo.png') }}">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="MaMa Café">
        <meta property="og:title" content="MaMa Café — Coffee • Boba • Ice Chocolate">
        <meta property="og:description" content="Good drinks. Good mood.">
        <meta property="og:image" content="{{ url('/mama-cafe-logo.png') }}">
        <meta property="og:image:width" content="1254">
        <meta property="og:image:height" content="1254">
        <meta property="og:image:type" content="image/png">
        <meta property="og:image:alt" content="MaMa Café coffee, boba, and ice chocolate logo">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="MaMa Café — Coffee • Boba • Ice Chocolate">
        <meta name="twitter:description" content="Good drinks. Good mood.">
        <meta name="twitter:image" content="{{ url('/mama-cafe-logo.png') }}">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@600;700&family=Great+Vibes&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,400;1,600&display=swap" rel="stylesheet">

        <style>
            body, html {
                font-family: 'Instrument Sans', ui-sans-serif, system-ui, sans-serif;
            }
        </style>

        @viteReactRefresh
        @vite(['resources/css/app.css', 'resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"])
        <x-inertia::head>
            <title>{{ config('app.name', 'MaMa Café') }}</title>
        </x-inertia::head>
    </head>
    <body class="font-sans antialiased">
        <x-inertia::app />
    </body>
</html>
